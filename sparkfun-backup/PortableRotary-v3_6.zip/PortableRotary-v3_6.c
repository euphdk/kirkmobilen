/*
    1-14-05
    Copyright Spark Fun Electronics� 2005
    
    (Nathan Seidle)

    Decoding of an old rotary dial telephone with a 16F88
    
    Uses Bloader/Screamer at 20MHz. Counts the ticks and translates them to the number to dial.
    Also detects the on hook/off hook status.
    
    All inputs are on RB4-7 with weak internal pull-ups.
    
    Uses onboard UART at 9600.

    9-14-05 : (Nathan Seidle) Added support for SIM cards with PIN numbers.
    Added scanning of GM862 report strings. Added auto-freq select : Phone
    attempts connection on North American frequencies. If no networks are
    detected, it will automatically swtich to European Frequencies.
    Once the phone is connected, and ready to place and receive calls, it will ring two short rings.

    10-25-05 : (Pete Dokter) Updated to work with touch tone pads
    
    11/16/05 : Changed debounce delay, fixed port settings. This is the code to ship on units starting 11-16-05
    
    3-2-07 : Added dial tone 350 and 440Hz square waves. Sounds decent, not great.
    
    11-8-07 : PCB v2.3 - Added jumper to pull EAR- to GND when dial tone is on.

*/

#define Clock_8MHz
#define Baud_9600
//#define DEBUG         //Uncomment this line for extra serial output for debugging

#include "C:\Global\Code\C\16F88.h"
#include "C:\Global\Code\c\int16CXX.h"

#pragma config |= 0x2910
#pragma origin 4

//Global variable declarations
#define HOOK        PORTB.4
#define ROTARY      PORTB.3
#define END_ROTARY  PORTB.1
#define RI          PORTB.0

#define GM862_ON    PORTA.7
#define STATUS_LED  PORTA.0

#define RING1       PORTA.2
#define RING2       PORTA.6
#define RING_POWER  PORTA.1

#define SQR350      PORTA.3
#define SQR440      PORTA.4
//#define EARGND      PORTB.7
#define EARGND      PORTB.6

#define OFF         1
#define ON          0

#define ERROR1      1
#define ERROR2      2
#define ERROR3      3
#define ERROR4      4
#define ERROR5      5
#define ERROR6      6
#define ERROR7      7
#define OK          250
#define ERROR       255

#define FIFO_SIZE   28

uns8 RX_In;
uns8 RX_Array[FIFO_SIZE];
//End Global variable declarations

interrupt serverX(void)
{
    int_save_registers    // W, STATUS (and PCLATH if required)
    char sv_FSR = FSR;  // save FSR if required

    if(RCIF) //Receive interrupt
    {
        RX_Array[RX_In] = RCREG; //Clears interrupt flag

        RX_In++;
        if(RX_In > FIFO_SIZE) RX_In = 0;

        //STATUS_LED ^= 1;
        
        CREN = 0;
        CREN = 1;
    }

    if(TMR1IF) //Timer1 Overflow Interrupt
    {
        //Setup Timer1 to fire every 1428us (1 / (350Hz * 2) )
        //1 TMR1 click is 4us (with prescaler of 8). 1428us / 4us = 357 clicks
        //65535 - 357 = 65178 = 0xFE9A
        TMR1ON = 0; TMR1H = 0xFE; TMR1L = 0x9F; TMR1ON = 1;

        SQR350 ^= 1;
        
        TMR1IF = 0; //Clear INT Flag
    }
    
    FSR = sv_FSR;               // restore FSR if saved
    int_restore_registers // W, STATUS (and PCLATH if required)
}


//Function declarations
#include "C:\Global\Code\Pics\Code\Stdio.c" // Basic Serial IO
#include "C:\Global\Code\Pics\Code\Delay.c" // Delays

void incoming_call(void);
void place_call(void);
void ring_it(void);
void short_ring_it(void);
uns8 get_TT(void);
void boot_up(void);

uns8 init_gm862(void);
uns8 get_response(const char* command_to_send, const char* string_to_find);
uns8 string_compare(const char *search_string, const char *find_string);
void error_mode(uns8 error_number);
uns8 get_pin(void);
void dial_tone(void);
//End Function declarations

void main()
{
    uns8 status_error;
    
    boot_up();
    
    //dial_tone();

    #ifdef DEBUG
        printf("Port-O-Rotary v3.3 10-29-07\r", 0);
        printf("Booting...\r", 0);
    #endif

    status_error = init_gm862();
    
    if(status_error != OK) error_mode(status_error);
    
    while(1)
    {
        STATUS_LED = OFF;

        while(HOOK == 0) //Wait for user to lift phone off hook
        {
            while(RI == 0) //Look for an incoming ring
                incoming_call();

            RING_POWER = OFF; //Power down Ringer
        }
        
        if(HOOK == 1) place_call(); //We need to dial out
    }

}

//The phone is off hook so we need to capture the rotary digits and dial the number
void place_call(void)
{
    uns8 dialed_number, counter, temp;
    uns8 number_length;
    uns16 x;

    uns8 phone_number[20];
    
    #ifdef DEBUG
        printf("Phone is off hook!\n\r Dial: ", 0);
    #endif
    
    //Begin Read Rotary
    number_length = 0;
    dialed_number = 0;
    counter = 0;

    //Play dial tone until the rotary is touched
    dial_tone();
    goto END_DIALTONE;
    
    for( ; counter < 30 ; counter++) //Assume we are on a 10-digit dialing type network
    {
        dialed_number = 0;
    
        //Wait for user to pause up to 4 seconds before sending out the number to the GM862
        for(x = 0 ; x < 400 ; x++)
        {
            delay_ms(10);

            if(END_ROTARY == 0) break; //Wait for user to start dialing
            if(HOOK == 0) goto HANG_UP; //If user hangs up,
            
            if(number_length == 0) x--; //Wait here indefinitely until the first number is dialed
        }
        
        if(x == 400 && number_length > 0) goto HARD_DIAL; //We've timed out 4 seconds, time to dial!

END_DIALTONE:

        delay_ms(50); //Wait for switch to debounce
    
        while(END_ROTARY == 0 && HOOK == 1)
        {
            //Now count how many times the mechnical switch toggles
            while(ROTARY == 1) 
                if(END_ROTARY == 1 || HOOK == 0) break;

            delay_ms(50); //Wait for switch to debounce
            STATUS_LED = ON;
    
            while(ROTARY == 0) 
                if(END_ROTARY == 1 || HOOK == 0) break;

            delay_ms(40); //Wait for switch to debounce

            STATUS_LED = OFF;
    
            dialed_number++;
        }
    
        if(HOOK == 0) goto HANG_UP;

        #ifdef DEBUG
            if(HOOK == 0) {printf("Hang up\n\r", 0); break;}
        #endif
    
        dialed_number--; //Rotary always has one extra closure that must be taken off
        
        number_length++; //Increase number length by 1 digit

        if (dialed_number == 10) dialed_number = 0; //Correct for operator call
    
        if(dialed_number >= 0 && dialed_number <= 9)
        {
            //Store this number into the array
            phone_number[counter] = dialed_number + '0';
            
            #ifdef DEBUG
                printf("%d", dialed_number);

                if (counter == 2 || counter == 5) printf("-", 0); //Fancy - easier to read
            #endif
        }
        else
        {
            //Some how we got a bad number - ignore it and try again
            counter--;

            #ifdef DEBUG
                printf("!", 0); //Error condition
            #endif


        }
    }
        
    
HARD_DIAL:

    STATUS_LED = ON;
    
    if(HOOK == 1) //Make sure we still have the phone off hook
    {
        //Once we are here, we have the number, time to send it to the cell phone
        printf("AT#CAP=2\r", 0); //Turn on handset
        delay_ms(100);

        printf("\ratd ", 0);
        for(counter = 0; counter < number_length ; counter++)
            putc(phone_number[counter]);
        putc(';');
        putc('\r'); //The number should now call
    
        while(HOOK == 1); //Wait for user to complete call
    }

HANG_UP:
    printf("ath\r", 0);
    delay_ms(1000);

    printf("AT#CAP=1\r", 0); //Turn off handset
    delay_ms(100);
    
}

void dial_tone(void)
{
    //This was all sorts of messed up because of a PCB error that was found later. See v3.3

    TRISA &= 0b.1110.0111; //0 = Output, 1 = Input
//    TRISB &= 0b.0111.1111; //0 = Output, 1 = Input
    //TRISB &= 0b.1011.1111; //0 = Output, 1 = Input

    OPTION.7 = 0; //Enable weak pull-ups
    //OPTION.7 = 1; //Disable weak pull-ups

    //EARGND = 0; //Ground half the Ear

    //Start 350Hz square wave
    //TMR1IF = 0;
    //TMR1ON = 0; TMR1H = 0xFE; TMR1L = 0x9F; 
    TMR1ON = 1;

    while(1)
    {
        SQR440 ^= 1;
        delay_us(248);
        
        if(END_ROTARY == 0) break; //Wait for user to start dialing
        if(HOOK == 0) break; //If user hangs up
    }
    
    TMR1ON = 0; //Stop 350Hz square wave

    //EARGND = 1; //Release half the Ear

    //Release pins so that GM862 can take over
    TRISA |= 0b.0001.1000; //0 = Output, 1 = Input
//    TRISB |= 0b.1000.0000; //0 = Output, 1 = Input
    //TRISB |= 0b.0100.0000; //0 = Output, 1 = Input
}

void incoming_call(void)
{
    RING_POWER = ON; //Power up Ringer

    //Now we need to delay but we need to monitor the hook as well
    //Works also as a ringer circuit charger
    uns16 i;
    for(i = 0 ; i < 300 ; i++)
    {
        delay_ms(10);
        if(HOOK == 1) break;
        if(RI == 1) return; //Make sure we still have an incoming call
    }

    ring_it(); //Ring bell for 1.5s
    if(RI == 1) return; //Make sure we still have an incoming call
            
    //Let us see if we have a call and the hook is off
    if(HOOK == 1)
    {
        RING_POWER = OFF; //Power down Ringer
        
        delay_ms(100);
        printf("AT#CAP=2\r", 0); //Turn on handset
        delay_ms(200);

        printf("ATA\r", 0);
        
        while(HOOK == 1); //Wait for user to complete call
                
        printf("ath\r", 0);
        delay_ms(1000);

        printf("AT#CAP=1\r", 0); //Turn off handset
        delay_ms(100);
    }
    
}

//Toggle the ring pins at 20Hz or 50ms
void ring_it(void)
{
    uns8 i;
    
    STATUS_LED = ON;

    for(i = 0 ; i < 45 ; i++)
    {
        if(HOOK == 1) break; //We need to monitor the hook
        if(RI == 1) break; //Make sure we still have an incoming call
        RING1 = 1;
        RING2 = 0;
        delay_ms(20);
        
        if(HOOK == 1) break; //We need to monitor the hook
        if(RI == 1) break; //Make sure we still have an incoming call
        RING1 = 0;
        RING2 = 1;
        delay_ms(20);
    } 

    RING1 = 0;
    RING2 = 0;

    STATUS_LED = OFF;
}

//Toggle the ring pins at 20Hz or 50ms
void short_ring_it(void)
{
    uns8 i;
    
    STATUS_LED = ON;

    for(i = 0 ; i < 4 ; i++)
    {
        RING1 = 1;
        RING2 = 0;
        delay_ms(20);
        
        RING1 = 0;
        RING2 = 1;
        delay_ms(20);
    } 

    RING1 = 0;
    RING2 = 0;

    STATUS_LED = OFF;
}

void boot_up(void)
{
    OSCCON = 0b.0111.0000; //Setup internal oscillator for 8MHz
    while(OSCCON.2 == 0); //Wait for frequency to stabilize
    
    //Setup Ports
    ANSEL = 0b.0000.0000; //Disable ADC on all pins

    PORTA = 0b.1000.0010;
    TRISA = 0b.0011.1000; //0 = Output, 1 = Input
    
    PORTB = 0b.0000.0000;
    TRISB = 0b.1111.1111; //0 = Output, 1 = Input (RX on RB2)

    OPTION.7 = 0; //Enable weak pull-ups

    //Setup the hardware UART module and interrupts
    //=============================================================
    SPBRG = 51; //8MHz for 9600 inital communication baud rate
    TXSTA = 0b.0010.0100; //8-bit asych mode, high speed uart enabled
    RCSTA = 0b.1001.0000; //Serial port enable, 8-bit asych continous receive mode
    //=============================================================

    //Set Interrupts!
    //===================================================

    //Setup Timer1 to control the 350Hz dial tone pin
    T1CON = 0b.0011.0000; //Prescale of 1:8 - 1 timer click = 4us with 8MHz internal osc

    TMR1IE = 1;
    PEIE = 1;
    GIE = 1;

    //All done, now we need to clear the RX buffer
    //RX_Array = 0;
    RX_In = 0;

    CREN = 0;
    CREN = 1; //This clears the jam-up in the RX buffer

    W = RCREG;
    RCIF = 0;
    RCIE = 1;
    //===================================================    

    //printf("Port-O-Rotary v3.3 10-29-07\r", 0);
    //printf("Booting...\r", 0);
    STATUS_LED = ON;
    delay_ms(250);
    
/*
    //Ringer test
    RING_POWER = ON; //Power up Ringer
    uns8 i;
    while(1)
    {
        STATUS_LED = ON;
        
        for(i = 0 ; i < 45 ; i++)
        {
            RING1 = 1;
            RING2 = 0;
            delay_ms(20);
            
            RING1 = 0;
            RING2 = 1;
            delay_ms(20);
        } 
    
        RING1 = 0;
        RING2 = 0;

        STATUS_LED = OFF;
        
        //RING_POWER = OFF; //Power down Ringer
        delay_ms(2000);
    }
*/    
    
}

//Powers up and initializes the GM862
//Will scan for connection and switch freq if no networks are seen
uns8 init_gm862(void)
{

    RING_POWER = ON; //Power up Ringer

    //Turn on GM862
    GM862_ON = 0;
    delay_ms(1500);
    GM862_ON = 1;

    //short_ring_it(); //Ring bell for 1.5s
    //ring_it(); //Ring bell

    delay_ms(6000);

    short_ring_it(); //Ring bell for 1.5s

    delay_ms(3000);

    STATUS_LED = OFF;

    //Clear the incoming array
    for(RX_In = 0 ; RX_In < FIFO_SIZE ; RX_In++) RX_Array[RX_In] = 0;
    RX_In = 0;

    //Autobaud the unit with the AT command
    if(get_response("AT\r", "OK") == ERROR) return ERROR1;

    //1.5 - Turn off any message waiting indicators
    if(get_response("AT#SELINT=2\r", "OK") == ERROR) return ERROR2;

//There was a batch of GM862s that came in that do not support WMI (old firmware)
//The following throws the command blindly
//    if(get_response("AT#MWI=0\r", "OK") == ERROR) return ERROR3;
    printf("AT#MWI=0\r", 0); //Send command to GM862
    delay_ms(500); //Absorb everything into the RX array for half second

    if(get_response("AT#SELINT=0\r", "OK") == ERROR) return ERROR2;

    //2 - check SIM card status (p12)
    //If AT+CPIN<cr> =
    //If PIN number is needed, wait for user
    //AT+CPIN=****<cr>
    if(get_response("AT+CPIN?\r", "+CPIN: READY") == ERROR)
    {
        //If we got an error, let us see if we need a pin number
        if(get_response("AT+CPIN?\r", "+CPIN: SIM PIN") == OK)
        {
            //If we do, then wait for the user to dial their pin
            short_ring_it(); //Ring bell for 1.5s
            delay_ms(500);
            short_ring_it(); //Ring bell for 1.5s
            delay_ms(500);
            short_ring_it(); //Ring bell for 1.5s
            delay_ms(500);

            STATUS_LED = ON;

            if(get_pin() == ERROR) return ERROR4;
        }
        else //We really do have an error, like no SIM card present
            return ERROR4;
    }

    //3 - Determine the best band to choose. Either Europe or North America
    //Try North America first. If, after 30 seconds, it's the other one, use it.
    while(1)
    {
        //Select North America cellular band
        if(get_response("AT#BND=1\r", "OK") == ERROR) return ERROR5;

        delay_ms(10000); //Wait 30 seconds for unit to attach to network
        if(get_response("AT+CSQ\r", "+CSQ: 99,99") == ERROR) break; //We assume the response was a signal level, so break

        delay_ms(10000); //Wait 30 seconds for unit to attach to network
        if(get_response("AT+CSQ\r", "+CSQ: 99,99") == ERROR) break; //We assume the response was a signal level, so break

        delay_ms(10000); //Wait 30 seconds for unit to attach to network

        if(get_response("AT+CSQ\r", "+CSQ: 99,99") == OK)
        {
            //If no signal is detected, try the Europe band
            if(get_response("AT#BND=0\r", "OK") == ERROR) return ERROR5;

            delay_ms(10000); //Wait 30 seconds for unit to attach to network
            if(get_response("AT+CSQ\r", "+CSQ: 99,99") == ERROR) break; //We assume the response was a signal level, so break

            delay_ms(10000); //Wait 30 seconds for unit to attach to network
            if(get_response("AT+CSQ\r", "+CSQ: 99,99") == ERROR) break; //We assume the response was a signal level, so break

            delay_ms(10000); //Wait 30 seconds for unit to attach to network

            if(get_response("AT+CSQ\r", "+CSQ: 99,99") == ERROR) return ERROR5; //If still no signal, then there is an antenna problem
        }
        else
            break; //If we get signal, then break the loop
    }

    //4 -
    if(get_response("AT#CAP=1\r", "OK") == ERROR) return ERROR6;

    //5 -
    if(get_response("AT+CLVL=9\r", "OK") == ERROR) return ERROR7;

    //We made it!!! Indicate to the user that the phone is online, ready to use

    short_ring_it(); //Ring bell for 1.5s
    STATUS_LED = ON;
    delay_ms(500);
    short_ring_it(); //Ring bell for 1.5s
    STATUS_LED = OFF;
    delay_ms(500);

    RING_POWER = OFF; //Power down Ringer

    return OK;

}

//Send a command to the GM862 and wait for a given response
//Return error is repsonse is not seen
uns8 get_response(const char* command_to_send, const char* string_to_find)
{
    uns8 i, response = 0;

    printf(command_to_send, 0); //Send command to GM862

    delay_ms(500); //Absorb everything into the RX array for half second

    response = string_compare(RX_Array, string_to_find);

//#ifdef DEBUG
//    printf("\n\rArray = ", 0);
//    for(RX_In = 0 ; RX_In < FIFO_SIZE ; RX_In++) printf("%u", RX_Array[RX_In]);
//#endif

    //Clear the RX Array buffer
    for(RX_In = 0 ; RX_In < FIFO_SIZE ; RX_In++) RX_Array[RX_In] = 0;
    RX_In = 0; //Reset array position to 0

    return response;
}

//Use to find a string within a search string
//search : "hithere\0"
//find : "the\0" - return OK
uns8 string_compare(const char *search_string, const char *find_string)
{

    uns8 find_spot, search_spot;
    uns8 spot_character, search_character;
    find_spot = 0;

    for(search_spot = 0 ; ; search_spot++)
    {
        if(find_string[find_spot] == '\0') return OK; //We've reached the end of the search string - that's good!
        if(search_string[search_spot] == '\0') return ERROR; //End of string found

        spot_character = find_string[find_spot]; //Compiler limit
        search_character = search_string[search_spot]; //Compiler limit

        if(spot_character == search_character) //We found another character
            find_spot++; //Look for the next spot in the search string
        else if(find_spot > 0) //No character found, so reset the find_spot
            find_spot = 0;
    }

    return 0;
}

//Here we scan the rotary for user input of up to 6 numbers constituting the PIN #
//Normally this is 4 numbers, but we can't be sure
//Ignore anything the hook might be doing...
uns8 get_pin(void)
{
    uns8 dialed_number, counter, temp;
    uns8 number_length;
    uns16 x;

    uns8 phone_number[10];

    number_length = 0;

    for(counter = 0 ; counter < 10 ; counter++) //Assume we are on a max 10-digit input length
    {
        dialed_number = 0;

        //Wait for user to pause up to 3 seconds before sending the pin number to the GM862
        for(x = 0 ; x < 400 ; x++)
        {
            delay_ms(10);

            if(END_ROTARY == 0) break; //Wait for user to start dialing
            //if(HOOK == 0) return ERROR; //If user hangs up,

            if(number_length == 0) x--; //Wait here indefinitely until the first number is dialed
        }

        if(x == 400 && number_length > 0) goto HARD_PIN; //We've timed out to 3 seconds, send PIN to SIM card

        delay_ms(30); //Wait for switch to debounce

        while(END_ROTARY == 0) // && HOOK == 1)
        {
            //Now count how many times the mechnical switch toggles
            while(ROTARY == 1)
                if(END_ROTARY == 1) break;// || HOOK == 0) break;

            delay_ms(30); //Wait for switch to debounce
            STATUS_LED = ON;

            while(ROTARY == 0)
                if(END_ROTARY == 1) break;// || HOOK == 0) break;

            delay_ms(30); //Wait for switch to debounce

            STATUS_LED = OFF;

            dialed_number++;
        }

        //if(HOOK == 0) return ERROR;

        #ifdef DEBUG
        //    if(HOOK == 0) {printf("Hang up\n\r", 0); break;}
        #endif

        dialed_number--; //Rotary always has one extra closure that must be taken off

        number_length++; //Increase number length by 1 digit

        if (dialed_number == 10) dialed_number = 0; //Correct for operator call

        if(dialed_number < 11)
        {
            //Store this number into the array
            phone_number[counter] = dialed_number + '0';

            #ifdef DEBUG
                printf("%d", dialed_number);

                if (counter == 2 || counter == 5) printf("-", 0); //Fancy - easier to read
            #endif
        }
        else
        {
            //Some how we got a bad number - ignore it and try again
            counter--;

            #ifdef DEBUG
                printf("!", 0); //Error condition
            #endif
        }
    }

HARD_PIN:

    STATUS_LED = ON;

    //if(HOOK == 1) //Make sure we still have the phone off hook
    //{
        //Once we are here, we have the number, time to send it to the SIM card
        printf("AT+CPIN=", 0);
        for(counter = 0; counter < number_length ; counter++)
            putc(phone_number[counter]);

        if(get_response("\r", "OK") == ERROR)
            return ERROR;
        else
        {
            //We really should record the PIN number to EEPROM...
            STATUS_LED = ON;
            delay_ms(500);
            STATUS_LED = OFF;
            delay_ms(500);
            STATUS_LED = ON;
            delay_ms(500);
            STATUS_LED = OFF;
            delay_ms(500);
        }

        //STATUS_LED = ON;
        //while(HOOK == 1); //Wait for user to hang up
    //}

    return OK;
}

//If we're here, we're screwed, just blink the PIC LED quickly
void error_mode(uns8 error_number)
{
    uns8 i;

    while(1)
    {
        for(i = 0 ; i < error_number ; i++)
        {
            STATUS_LED = ON;
            delay_ms(200);
            STATUS_LED = OFF;
            delay_ms(200);
        }

        delay_ms(3000);
    }
}
